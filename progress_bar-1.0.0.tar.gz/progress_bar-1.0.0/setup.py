from setuptools import setup, find_packages

setup(
    name='progress_bar',
    version='1.0.0',
    author='I am a strong paper',
    author_email='wsqz123456789@outlook.com',
    description='A custom progress bar library',
    packages=find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)